# Primer starter

Primer is configured with `remote_theme` because it is not in GitHub's current out-of-the-box supported theme list.

Remote theme: `pages-themes/primer@v0.6.0`
